<template>

    <p class="card-footer-item">
        <slot/>
    </p>

</template>

<script>

export default {
    name: 'CardControl',
};

</script>
